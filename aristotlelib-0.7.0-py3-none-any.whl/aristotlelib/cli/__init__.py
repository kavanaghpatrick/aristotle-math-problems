"""CLI commands for the Aristotle SDK."""
