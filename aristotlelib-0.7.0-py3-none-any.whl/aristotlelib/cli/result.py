import argparse
from aristotlelib.cli.api_action import APIAction
from aristotlelib.project import Project


class ResultAction(APIAction):
    @property
    def command_name(self) -> str:
        return "result"

    @property
    def description(self) -> str:
        return "Waits until a result is ready and then downloads the result."

    def add_action_arguments(self) -> None:
        self.parser.add_argument("project_id", type=str)

        self.parser.add_argument(
            "--destination",
            type=str,
            help="Path to save the solution directory.",
        )

        self.parser.add_argument(
            "--wait",
            action="store_true",
            help="Wait for completion before returning (default: don't wait)",
        )

    async def run_action(self, args: argparse.Namespace) -> None:
        project = await Project.from_id(args.project_id)

        if args.wait:
            await project.wait_for_completion(destination=args.destination)
        else:
            await project.get_solution_if_complete(destination=args.destination)
