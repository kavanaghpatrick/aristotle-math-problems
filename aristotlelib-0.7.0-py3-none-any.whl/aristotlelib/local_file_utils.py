import logging
from pathlib import Path
import pathspec

# Set up logger for this module
logger = logging.getLogger("aristotle")


MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024

MATHLIB_INCLUDED_STD_PACKAGES = (
    "Cli",
    "LeanSearchClient",
    "Qq",
    "aesop",
    "batteries",
    "importGraph",
    "mathlib",
    "plausible",
    "proofwidgets",
)

LEAN_PROJECT_IGNORED_FILE_PATTERNS = [
    "*.setup.json",
    "*.olean",
    "*.olean.lock",
    "*.olean.trace",
    "*.olean.hash",
    "*.olean.private",
    "*.olean.private.hash",
    "*.olean.server",
    "*.olean.server.hash",
    "*.ilean",
    "*.ilean.trace",
    "*.ilean.hash",
    "*.trace",
    "*.ir",
    "*.ir.hash",
    "*.o",
    "*.so",
    "*.so.hash",
    # any ir files
    "**/.lake/build/ir",
    "**/.lake/build/bin",
    # all nested .git repos
    "**/.git",
] + [f"**/.lake/packages/{pkg}" for pkg in MATHLIB_INCLUDED_STD_PACKAGES]

EXPECTED_TOOLCHAINS = [
    "leanprover/lean4:v4.24.0",
    "leanprover/lean4:v4.24.1",
]


class LeanProjectError(Exception):
    """Exception raised for Lean project-related errors."""

    pass


def should_skip_input_file(file_path: Path, base_path: Path | None = None) -> bool:
    """Check if a file should be skipped based on Lean project ignore patterns.

    Args:
        file_path: Path to the file to check.
        base_path: If provided, the file path will be made relative to this before matching.
            This is important for patterns like "**/.lake/build/ir" to match correctly.

    Returns:
        True if the file should be skipped, False otherwise.
    """
    spec = pathspec.PathSpec.from_lines(
        "gitwildmatch", LEAN_PROJECT_IGNORED_FILE_PATTERNS
    )

    if base_path is not None:
        rel_path = file_path.relative_to(base_path)
    else:
        rel_path = file_path

    return spec.match_file(str(rel_path))


def read_file_safely(file_path: Path, max_size: int = MAX_FILE_SIZE_BYTES) -> bytes:
    """
    Read a file safely, checking size before loading into memory.

    Args:
        file_path: Path to file to read
        max_size: Maximum allowed file size in bytes

    Returns:
        File contents as bytes

    Raises:
        FileSizeError: If file is too large
        OSError: If file cannot be read
    """
    file_size = file_path.stat().st_size
    if file_size > max_size:
        raise LeanProjectError(
            f"File {file_path} is too large ({file_size} bytes). Maximum allowed size is {max_size} bytes."
        )

    with open(file_path, "rb") as f:
        return f.read()


def get_lean_toolchain_version(project_dir: Path) -> str | None:
    """
    Get the lean-toolchain version from the project.

    Looks for the outermost lean-toolchain file (starting from the top level directory).

    Args:
        project_dir: Path to the project directory

    Returns:
        The toolchain version string if found, None otherwise
    """
    toolchain_path = project_dir / "lean-toolchain"
    if toolchain_path.is_file():
        try:
            return toolchain_path.read_text().strip()
        except Exception as e:
            logger.warning(f"Failed to read lean-toolchain file: {e}")
            return None

    # If not found at top level, search for it in subdirectories
    for toolchain_file in sorted(
        project_dir.rglob("lean-toolchain"), key=lambda p: len(p.parts)
    ):
        try:
            return toolchain_file.read_text().strip()
        except Exception as e:
            logger.warning(
                f"Failed to read lean-toolchain file at {toolchain_file}: {e}"
            )
            return None

    return None


def has_any_lean_files(project_dir: Path) -> bool:
    """
    Check if the project directory contains any .lean files.

    Args:
        project_dir: Path to the project directory

    Returns:
        True if at least one .lean file exists, False otherwise
    """
    return any(project_dir.rglob("*.lean"))
