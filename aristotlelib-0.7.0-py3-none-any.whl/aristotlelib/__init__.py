import logging

from aristotlelib.api_request import set_api_key

from aristotlelib.project import Project, ProjectStatus
from aristotlelib.api_request import AristotleRequestClient, AristotleAPIError


# Custom formatter that only shows level for ERROR and above
class _LogFormatter(logging.Formatter):
    def format(self, record):
        if record.levelno >= logging.ERROR:
            return f"{record.levelname} - {record.getMessage()}"
        return record.getMessage()


# Configure logging for SDK users
_handler = logging.StreamHandler()
_handler.setFormatter(_LogFormatter())
logging.root.addHandler(_handler)
logging.root.setLevel(logging.INFO)

# Disable verbose HTTP client logging
logging.getLogger("httpx").disabled = True
logging.getLogger("httpcore").disabled = True
